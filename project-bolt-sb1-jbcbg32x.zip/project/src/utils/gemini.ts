const GEMINI_API_KEY = import.meta.env.VITE_GEMINI_API_KEY;

export interface OnboardingData {
  goal: string;
  time: string;
  style: string;
  level: string;
}

const buildSystemContext = (onboardingData: OnboardingData, coursesContext: string): string => {
  return `
Você é o MentorIA, um tutor de aprendizado personalizado integrado à plataforma CEFIS.

PERFIL DO ALUNO:
- Objetivo: ${onboardingData.goal}
- Estilo de aprendizagem: ${onboardingData.style}
- Tempo disponível por dia: ${onboardingData.time}
- Nível de conhecimento: ${onboardingData.level}

CURSOS DISPONÍVEIS NA CEFIS (use para recomendar):
${coursesContext}

INSTRUÇÕES:
- Responda sempre em português brasileiro
- Adapte a linguagem ao estilo de aprendizagem do aluno
- Se for visual: use esquemas, listas, estruturas visuais
- Se for auditivo: use linguagem conversacional e narrativa
- Se for lendo: use texto rico e referências
- Se for praticando: use exemplos e exercícios
- Seja direto, empático e motivador
- Quando recomendar curso, mencione o título real da CEFIS
- Nunca invente conteúdo — se não souber, diga que vai buscar
`;
};

export const askMentor = async (
  userMessage: string,
  onboardingData: OnboardingData,
  coursesContext: string
): Promise<string> => {
  if (!GEMINI_API_KEY) {
    throw new Error('Gemini API key not configured');
  }

  const systemContext = buildSystemContext(onboardingData, coursesContext);

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: systemContext + '\n\nAluno: ' + userMessage }] }],
          generationConfig: { maxOutputTokens: 1024, temperature: 0.7 }
        })
      }
    );

    if (!response.ok) {
      throw new Error('Failed to get AI response');
    }

    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Error calling Gemini API:', error);
    throw error;
  }
};

export const generateMicroLesson = async (
  theme: string,
  onboardingData: OnboardingData
): Promise<string> => {
  if (!GEMINI_API_KEY) {
    throw new Error('Gemini API key not configured');
  }

  const prompt = `Crie uma micro-aula de 10 minutos sobre: ${theme}

Formato obrigatório:
## 📌 O que é
[2-3 linhas simples]

## ⚡ 3 pontos essenciais
1. ...
2. ...
3. ...

## 🧠 Exemplo prático
[exemplo real e concreto]

## ✅ Checklist rápido
- [ ] ...
- [ ] ...
- [ ] ...

## ❓ Pergunta para fixar
[uma pergunta de múltipla escolha com resposta]

Adapte para alguém que aprende de forma ${onboardingData.style} e tem nível ${onboardingData.level}.`;

  try {
    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash:generateContent?key=${GEMINI_API_KEY}`,
      {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          contents: [{ parts: [{ text: prompt }] }],
          generationConfig: { maxOutputTokens: 1024, temperature: 0.7 }
        })
      }
    );

    if (!response.ok) {
      throw new Error('Failed to generate micro lesson');
    }

    const data = await response.json();
    return data.candidates[0].content.parts[0].text;
  } catch (error) {
    console.error('Error generating micro lesson:', error);
    throw error;
  }
};
