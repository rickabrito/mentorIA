const CEFIS_V1_BASE_URL = '/cefis-api';
const CEFIS_V3_BASE_URL = '/cefis-v3';

export interface CEFISUser {
  id: number;
  name: string;
  email: string;
}

export interface CEFISCourse {
  id: number;
  title: string;
  duration: number;
  averageRating: number;
  thumbnail?: string;
  description?: string;
}

export interface CEFISTrack {
  id: number;
  title: string;
  description?: string;
  courses?: CEFISCourse[];
}

export const cefisAPI = {
  async login(email: string, password: string): Promise<{ key: string; user: CEFISUser }> {
    try {
      const response = await fetch(`${CEFIS_V1_BASE_URL}/api/v1/login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, pass: password }),
      });

      if (!response.ok) {
        if (response.status === 401) {
          throw new Error('E-mail ou senha incorretos');
        } else if (response.status >= 500) {
          throw new Error('Erro no servidor CEFIS. Tente em instantes.');
        } else {
          throw new Error('Erro inesperado. Tente novamente.');
        }
      }

      const data = await response.json();

      if (!data.data || !data.data.key) {
        throw new Error('Resposta inválida do servidor');
      }

      return {
        key: data.data.key,
        user: data.data.user,
      };
    } catch (error) {
      if (error instanceof TypeError && error.message === 'Failed to fetch') {
        throw new Error('Erro de conexão. Tente novamente.');
      }
      throw error;
    }
  },

  async getCourses(key: string, count: number = 20, page: number = 1): Promise<CEFISCourse[]> {
    try {
      const response = await fetch(
        `${CEFIS_V3_BASE_URL}/courses?count=${count}&page=${page}`,
        {
          headers: {
            'Authorization': `Bearer ${key}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch courses');
      }

      const data = await response.json();
      return data.data || [];
    } catch (error) {
      console.error('Error fetching courses:', error);
      return [];
    }
  },

  async getTracks(key: string, count: number = 10, page: number = 1): Promise<CEFISTrack[]> {
    try {
      const response = await fetch(
        `${CEFIS_V3_BASE_URL}/tracks?count=${count}&page=${page}`,
        {
          headers: {
            'Authorization': `Bearer ${key}`,
          },
        }
      );

      if (!response.ok) {
        throw new Error('Failed to fetch tracks');
      }

      const data = await response.json();
      return data.data || [];
    } catch (error) {
      console.error('Error fetching tracks:', error);
      return [];
    }
  },
};

export const formatDuration = (seconds: number): string => {
  const hours = Math.floor(seconds / 3600);
  const minutes = Math.floor((seconds % 3600) / 60);

  if (hours > 0) {
    return `${hours}h ${minutes}min`;
  }
  return `${minutes}min`;
};

export const PLACEHOLDER_COURSES: CEFISCourse[] = [
  {
    id: 1,
    title: 'Direito Constitucional para Concursos',
    duration: 7200,
    averageRating: 4.8,
  },
  {
    id: 2,
    title: 'Direito Administrativo Avançado',
    duration: 5400,
    averageRating: 4.6,
  },
  {
    id: 3,
    title: 'Técnicas de Estudo e Memorização',
    duration: 3600,
    averageRating: 4.9,
  },
];
