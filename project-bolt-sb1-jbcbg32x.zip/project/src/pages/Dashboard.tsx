import { useState, useEffect } from 'react';
import { useNavigate } from 'react-router-dom';
import {
  Sparkles,
  Target,
  Clock,
  Eye,
  Ear,
  BookOpen,
  Zap,
  Leaf,
  Rocket,
  Send,
  ExternalLink,
  MessageCircle,
  User,
  LogOut,
} from 'lucide-react';
import { formatDuration, type CEFISCourse, PLACEHOLDER_COURSES } from '../utils/api';
import { askMentor, generateMicroLesson, type OnboardingData } from '../utils/gemini';

interface ChatMessage {
  role: 'user' | 'assistant';
  content: string;
}

export default function Dashboard() {
  const navigate = useNavigate();
  const [user, setUser] = useState<{ name: string } | null>(null);
  const [onboardingData, setOnboardingData] = useState<OnboardingData | null>(null);
  const [courses, setCourses] = useState<CEFISCourse[]>([]);
  const [loading, setLoading] = useState(true);

  // Chat state
  const [chatMessages, setChatMessages] = useState<ChatMessage[]>([]);
  const [chatInput, setChatInput] = useState('');
  const [chatLoading, setChatLoading] = useState(false);

  // Micro lesson state
  const [microLessonTheme, setMicroLessonTheme] = useState('');
  const [microLessonContent, setMicroLessonContent] = useState('');
  const [microLessonLoading, setMicroLessonLoading] = useState(false);

  useEffect(() => {
    // Load user data
    const userStr = localStorage.getItem('cefis_user');
    const userData = userStr ? JSON.parse(userStr) : null;
    setUser(userData);

    // Load onboarding data
    const onboardingStr = localStorage.getItem('onboarding_data');
    const onboarding = onboardingStr ? JSON.parse(onboardingStr) : null;
    setOnboardingData(onboarding);

    if (!onboardingStr) {
      navigate('/onboarding');
      return;
    }

    // Load courses
    const coursesStr = localStorage.getItem('cefis_courses');
    if (coursesStr) {
      const coursesData = JSON.parse(coursesStr);
      setCourses(coursesData.length > 0 ? coursesData.slice(0, 3) : PLACEHOLDER_COURSES);
      setLoading(false);
    } else {
      // If no courses, use placeholders
      setCourses(PLACEHOLDER_COURSES);
      setLoading(false);
    }
  }, [navigate]);

  const getGoalLabel = (value: string) => {
    const goals: Record<string, string> = {
      concurso: 'Passar em concurso público',
      oab: 'Aprovação na OAB',
      carreira: 'Crescer na carreira jurídica',
      interesse: 'Aprender por interesse',
    };
    return goals[value] || value;
  };

  const getStyleIcon = (value: string) => {
    const icons: Record<string, React.ReactNode> = {
      visual: <Eye className="w-5 h-5" />,
      auditivo: <Ear className="w-5 h-5" />,
      lendo: <BookOpen className="w-5 h-5" />,
      praticando: <Zap className="w-5 h-5" />,
    };
    return icons[value] || <BookOpen className="w-5 h-5" />;
  };

  const getStyleLabel = (value: string) => {
    const styles: Record<string, string> = {
      visual: 'Visual',
      auditivo: 'Auditivo',
      lendo: 'Lendo',
      praticando: 'Praticando',
    };
    return styles[value] || value;
  };

  const getTimeLabel = (value: string) => {
    const times: Record<string, string> = {
      '10min': '10 minutos',
      '30min': '30 minutos',
      '1h': '1 hora',
      '2h+': '2+ horas',
    };
    return times[value] || value;
  };

  const getLevelLabel = (value: string) => {
    const levels: Record<string, string> = {
      iniciante: 'Iniciante',
      intermediario: 'Intermediário',
      avancado: 'Avançado',
    };
    return levels[value] || value;
  };

  const handleSendChat = async () => {
    if (!chatInput.trim() || !onboardingData) return;

    const message = chatInput.trim();
    setChatInput('');
    setChatMessages([...chatMessages, { role: 'user', content: message }]);
    setChatLoading(true);

    try {
      const coursesContext = courses.map((c) => `- ${c.title}`).join('\n');
      const response = await askMentor(message, onboardingData, coursesContext);
      setChatMessages((prev) => [...prev, { role: 'assistant', content: response }]);
    } catch (error) {
      setChatMessages((prev) => [
        ...prev,
        { role: 'assistant', content: 'Desculpe, tive um problema ao processar sua pergunta. Pode tentar novamente?' },
      ]);
    } finally {
      setChatLoading(false);
    }
  };

  const handleGenerateMicroLesson = async () => {
    if (!microLessonTheme.trim() || !onboardingData) return;

    const theme = microLessonTheme.trim();
    setMicroLessonTheme('');
    setMicroLessonLoading(true);
    setMicroLessonContent('');

    try {
      const response = await generateMicroLesson(theme, onboardingData);
      setMicroLessonContent(response);
    } catch (error) {
      setMicroLessonContent('Desculpe, tive um problema ao gerar a micro-aula. Pode tentar novamente?');
    } finally {
      setMicroLessonLoading(false);
    }
  };

  const handleLogout = () => {
    localStorage.clear();
    navigate('/');
  };

  if (loading || !onboardingData) {
    return (
      <div className="min-h-screen flex items-center justify-center">
        <div className="text-center">
          <div className="w-12 h-12 border-4 border-purple-400/30 border-t-purple-400 rounded-full animate-spin mb-4 mx-auto" />
          <p className="text-gray-400">Carregando seu dashboard...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-[#0A0A0F]">
      {/* Top Bar */}
      <header className="sticky top-0 z-50 backdrop-blur-xl bg-[#0A0A0F]/80 border-b border-white/10">
        <div className="max-w-7xl mx-auto px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Sparkles className="w-8 h-8 text-purple-400" />
            <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
              MentorIA
            </span>
          </div>

          <div className="flex items-center gap-4">
            <div className="flex items-center gap-2 text-gray-300">
              <User className="w-5 h-5" />
              <span className="font-medium">Olá, {user?.name?.split(' ')[0] || 'Estudante'}!</span>
            </div>
            <button
              onClick={handleLogout}
              className="p-2 hover:bg-white/10 rounded-lg transition-colors"
              title="Sair"
            >
              <LogOut className="w-5 h-5 text-gray-400" />
            </button>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-6 py-8 space-y-8">
        {/* Section 1: Cognitive Profile */}
        <section className="fade-in">
          <div className="glass glow-border rounded-2xl p-8">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <Target className="w-6 h-6 text-purple-400" />
              Perfil Cognitivo
            </h2>
            <div className="grid md:grid-cols-4 gap-6">
              <div className="bg-white/5 rounded-xl p-4">
                <p className="text-sm text-gray-400 mb-1">Objetivo</p>
                <p className="font-medium">{getGoalLabel(onboardingData.goal)}</p>
              </div>
              <div className="bg-white/5 rounded-xl p-4 flex items-center gap-3">
                <div className="p-2 rounded-lg bg-purple-500/20">
                  {getStyleIcon(onboardingData.style)}
                </div>
                <div>
                  <p className="text-sm text-gray-400 mb-1">Estilo</p>
                  <p className="font-medium">{getStyleLabel(onboardingData.style)}</p>
                </div>
              </div>
              <div className="bg-white/5 rounded-xl p-4 flex items-center gap-3">
                <Clock className="w-5 h-5 text-cyan-400" />
                <div>
                  <p className="text-sm text-gray-400 mb-1">Tempo diário</p>
                  <p className="font-medium">{getTimeLabel(onboardingData.time)}</p>
                </div>
              </div>
              <div className="bg-white/5 rounded-xl p-4 flex items-center gap-3">
                {onboardingData.level === 'iniciante' ? (
                  <Leaf className="w-5 h-5 text-green-400" />
                ) : onboardingData.level === 'avancado' ? (
                  <Rocket className="w-5 h-5 text-purple-400" />
                ) : (
                  <BookOpen className="w-5 h-5 text-blue-400" />
                )}
                <div>
                  <p className="text-sm text-gray-400 mb-1">Nível</p>
                  <p className="font-medium">{getLevelLabel(onboardingData.level)}</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Section 2: Study Plan */}
        <section className="fade-in" style={{ animationDelay: '0.1s' }}>
          <div className="glass glow-border rounded-2xl p-8">
            <h2 className="text-2xl font-bold mb-6">Seu plano personalizado</h2>
            <div className="grid md:grid-cols-3 gap-6">
              {courses.map((course, index) => (
                <div
                  key={course.id || index}
                  className="bg-white/5 rounded-xl p-6 card-hover border border-white/10"
                >
                  <h3 className="font-bold text-lg mb-3 line-clamp-2">{course.title}</h3>
                  <div className="space-y-2 mb-4">
                    <p className="text-sm text-gray-400">
                      Duração: {formatDuration(course.duration)}
                    </p>
                    <div className="flex items-center gap-1">
                      <span className="text-yellow-400">★</span>
                      <span className="text-sm text-gray-300">{course.averageRating || 4.5}</span>
                    </div>
                  </div>
                  <a
                    href={`https://cefis.com.br/cursos/${course.id}`}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-2 text-purple-400 hover:text-purple-300 transition-colors text-sm font-medium"
                  >
                    Ver curso
                    <ExternalLink className="w-4 h-4" />
                  </a>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* Section 3: 10-Minute Mode */}
        <section className="fade-in" style={{ animationDelay: '0.2s' }}>
          <div className="glass rounded-2xl p-8 border-2 border-purple-500/50 shadow-[0_0_30px_rgba(108,99,255,0.3)]">
            <div className="flex items-start gap-4 mb-6">
              <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500/30 to-cyan-500/30">
                <Zap className="w-8 h-8 text-purple-400" />
              </div>
              <div>
                <h2 className="text-2xl font-bold">Modo 10 Minutos</h2>
                <p className="text-gray-400">Peça uma micro-aula agora sobre qualquer tema</p>
              </div>
            </div>

            <div className="flex gap-4 mb-6">
              <input
                type="text"
                value={microLessonTheme}
                onChange={(e) => setMicroLessonTheme(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleGenerateMicroLesson()}
                placeholder="Sobre qual tema você quer aprender agora?"
                className="flex-1 bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white placeholder-gray-500"
              />
              <button
                onClick={handleGenerateMicroLesson}
                disabled={microLessonLoading || !microLessonTheme.trim()}
                className="btn-gradient px-6 py-3 rounded-xl font-semibold disabled:opacity-50"
              >
                {microLessonLoading ? 'Gerando...' : 'Gerar micro-aula'}
              </button>
            </div>

            {microLessonLoading && (
              <div className="space-y-3">
                <div className="skeleton h-4 w-3/4 rounded"></div>
                <div className="skeleton h-4 w-1/2 rounded"></div>
                <div className="skeleton h-4 w-2/3 rounded"></div>
              </div>
            )}

            {microLessonContent && !microLessonLoading && (
              <div className="bg-white/5 rounded-xl p-6 border border-white/10 prose prose-invert max-w-none">
                <div className="whitespace-pre-wrap">{microLessonContent}</div>
              </div>
            )}
          </div>
        </section>

        {/* Section 4: Chat with MentorIA */}
        <section className="fade-in" style={{ animationDelay: '0.3s' }}>
          <div className="glass glow-border rounded-2xl p-8">
            <h2 className="text-2xl font-bold mb-6 flex items-center gap-2">
              <MessageCircle className="w-6 h-6 text-cyan-400" />
              Pergunte ao seu mentor
            </h2>

            {/* Chat Messages */}
            <div className="min-h-[300px] max-h-[500px] overflow-y-auto mb-6 space-y-4 pr-2">
              {chatMessages.length === 0 && (
                <div className="text-center text-gray-400 py-12">
                  <MessageCircle className="w-12 h-12 mx-auto mb-4 opacity-50" />
                  <p>Olá! Sou seu mentor personalizado.</p>
                  <p className="text-sm mt-2">Pergunte qualquer coisa sobre seus estudos!</p>
                </div>
              )}
              {chatMessages.map((msg, index) => (
                <div
                  key={index}
                  className={`flex ${msg.role === 'user' ? 'justify-end' : 'justify-start'}`}
                >
                  <div
                    className={`chat-message rounded-2xl p-4 ${
                      msg.role === 'user'
                        ? 'bg-purple-500/20 border border-purple-500/30'
                        : 'bg-white/5 border border-white/10'
                    }`}
                  >
                    {msg.role === 'assistant' && (
                      <div className="flex items-center gap-2 mb-2">
                        <Sparkles className="w-4 h-4 text-purple-400" />
                        <span className="text-sm text-purple-400 font-medium">MentorIA</span>
                      </div>
                    )}
                    <div className="whitespace-pre-wrap">{msg.content}</div>
                  </div>
                </div>
              ))}
              {chatLoading && (
                <div className="flex justify-start">
                  <div className="bg-white/5 border border-white/10 rounded-2xl p-4 inline-flex items-center gap-2">
                    <div className="flex gap-1">
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0s' }} />
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.1s' }} />
                      <div className="w-2 h-2 bg-purple-400 rounded-full animate-bounce" style={{ animationDelay: '0.2s' }} />
                    </div>
                    <span className="text-sm text-gray-400">pensando...</span>
                  </div>
                </div>
              )}
            </div>

            {/* Chat Input */}
            <div className="flex gap-4">
              <input
                type="text"
                value={chatInput}
                onChange={(e) => setChatInput(e.target.value)}
                onKeyPress={(e) => e.key === 'Enter' && handleSendChat()}
                placeholder="Digite sua pergunta..."
                className="flex-1 bg-white/5 border border-white/10 rounded-xl py-3 px-4 text-white placeholder-gray-500"
                disabled={chatLoading}
              />
              <button
                onClick={handleSendChat}
                disabled={chatLoading || !chatInput.trim()}
                className="btn-gradient px-6 py-3 rounded-xl font-semibold disabled:opacity-50 flex items-center gap-2"
              >
                <Send className="w-5 h-5" />
              </button>
            </div>
          </div>
        </section>
      </main>
    </div>
  );
}
