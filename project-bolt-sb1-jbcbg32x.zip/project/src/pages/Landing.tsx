import { useNavigate } from 'react-router-dom';
import { Target, BookOpen, Clock, Sparkles } from 'lucide-react';

export default function Landing() {
  const navigate = useNavigate();

  return (
    <div className="relative min-h-screen overflow-hidden">
      {/* Animated gradient background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="gradient-blob blob-purple w-96 h-96 -top-20 -left-20" style={{ animationDelay: '0s' }}></div>
        <div className="gradient-blob blob-cyan w-96 h-96 -bottom-20 -right-20" style={{ animationDelay: '5s' }}></div>
        <div className="gradient-blob blob-purple w-64 h-64 top-1/2 left-1/2" style={{ animationDelay: '10s' }}></div>
      </div>

      {/* Content */}
      <div className="relative z-10 min-h-screen flex flex-col">
        {/* Header */}
        <header className="w-full px-6 py-8">
          <div className="max-w-7xl mx-auto flex items-center">
            <div className="flex items-center gap-2">
              <Sparkles className="w-8 h-8 text-purple-400" />
              <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                MentorIA
              </span>
            </div>
          </div>
        </header>

        {/* Hero Section */}
        <main className="flex-1 flex flex-col items-center justify-center px-6 pb-20">
          <div className="text-center max-w-4xl fade-in">
            <h1 className="text-5xl md:text-6xl lg:text-7xl font-bold mb-6 leading-tight">
              Aprenda do jeito que{' '}
              <span className="bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
                seu cérebro aprende.
              </span>
            </h1>

            <p className="text-xl md:text-2xl text-gray-300 mb-12 max-w-3xl mx-auto leading-relaxed">
              MentorIA analisa seu perfil cognitivo e cria um plano de estudos personalizado com conteúdo real da CEFIS.
            </p>

            <button
              onClick={() => navigate('/login')}
              className="btn-gradient text-white font-semibold text-lg px-12 py-4 rounded-full inline-flex items-center gap-2 glow-purple"
            >
              Começar diagnóstico gratuito
              <Sparkles className="w-5 h-5" />
            </button>
          </div>

          {/* Feature Cards */}
          <div className="grid md:grid-cols-3 gap-6 mt-20 w-full max-w-6xl">
            <FeatureCard
              icon={<Target className="w-8 h-8 text-purple-400" />}
              title="Plano adaptativo"
              description="Adapta-se ao seu estilo de aprendizagem único, ajustando automaticamente o conteúdo e ritmo dos estudos."
            />
            <FeatureCard
              icon={<BookOpen className="w-8 h-8 text-cyan-400" />}
              title="Conteúdo real CEFIS"
              description="Acesse cursos reais da maior plataforma de educação jurídica do Brasil, selecionados para seu perfil."
            />
            <FeatureCard
              icon={<Clock className="w-8 h-8 text-purple-400" />}
              title="Modo 10 minutos"
              description="Micro-learning sessions projetadas para aprender algo novo mesmo com agenda corrida."
            />
          </div>
        </main>
      </div>
    </div>
  );
}

function FeatureCard({ icon, title, description }: { icon: React.ReactNode; title: string; description: string }) {
  return (
    <div className="glass glow-border rounded-2xl p-8 card-hover fade-in" style={{ animationDelay: '0.2s' }}>
      <div className="flex items-start gap-4">
        <div className="p-3 rounded-xl bg-gradient-to-br from-purple-500/20 to-cyan-500/20">
          {icon}
        </div>
        <div>
          <h3 className="text-xl font-semibold mb-3">{title}</h3>
          <p className="text-gray-400 leading-relaxed">{description}</p>
        </div>
      </div>
    </div>
  );
}
