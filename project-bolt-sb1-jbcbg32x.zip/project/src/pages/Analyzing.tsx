import { useEffect, useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Sparkles } from 'lucide-react';
import { cefisAPI, PLACEHOLDER_COURSES } from '../utils/api';

const MESSAGES = [
  'Analisando seu perfil cognitivo...',
  'Identificando lacunas de conhecimento...',
  'Mapeando estilo de aprendizagem...',
  'Buscando conteúdo real da CEFIS...',
  'Criando seu plano personalizado...',
  'Finalizando recomendações...',
];

export default function Analyzing() {
  const navigate = useNavigate();
  const [currentMessage, setCurrentMessage] = useState(0);

  useEffect(() => {
    const fetchCEFISData = async () => {
      const key = localStorage.getItem('cefis_key');

      // Fetch courses and tracks in parallel
      const [courses, tracks] = await Promise.all([
        key ? cefisAPI.getCourses(key, 20, 1) : Promise.resolve([]),
        key ? cefisAPI.getTracks(key, 10, 1) : Promise.resolve([]),
      ]);

      // Store results - use placeholders if API returns empty
      localStorage.setItem('cefis_courses', JSON.stringify(courses.length > 0 ? courses : PLACEHOLDER_COURSES));
      localStorage.setItem('cefis_tracks', JSON.stringify(tracks));
    };

    fetchCEFISData();

    // Rotate messages every 1.5 seconds
    const messageInterval = setInterval(() => {
      setCurrentMessage((prev) => (prev + 1) % MESSAGES.length);
    }, 1500);

    // Navigate after 9 seconds
    const navigationTimeout = setTimeout(() => {
      navigate('/dashboard');
    }, 9000);

    return () => {
      clearInterval(messageInterval);
      clearTimeout(navigationTimeout);
    };
  }, [navigate]);

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated gradient background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="gradient-blob blob-purple w-96 h-96 -top-20 -left-20"></div>
        <div className="gradient-blob blob-cyan w-96 h-96 -bottom-20 -right-20"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 text-center fade-in">
        {/* Pulsing Logo */}
        <div className="mb-8 flex justify-center">
          <div className="relative">
            <div className="absolute inset-0 bg-purple-500/30 rounded-full blur-3xl pulse-animation"></div>
            <div className="relative glass glow-border rounded-full p-12 pulse-animation">
              <Sparkles className="w-20 h-20 text-purple-400" />
            </div>
          </div>
        </div>

        {/* Logo Text */}
        <h1 className="text-4xl font-bold mb-8 bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
          MentorIA
        </h1>

        {/* Animated Message */}
        <div className="min-h-[3rem] flex items-center justify-center">
          <p className="text-xl text-gray-300 transition-opacity duration-500">
            {MESSAGES[currentMessage]}
          </p>
        </div>

        {/* Loading dots */}
        <div className="flex justify-center gap-2 mt-6">
          {[0, 1, 2].map((i) => (
            <div
              key={i}
              className="w-3 h-3 bg-purple-400 rounded-full"
              style={{
                animation: 'pulse 1.5s ease-in-out infinite',
                animationDelay: `${i * 0.2}s`,
              }}
            />
          ))}
        </div>
      </div>

      {/* Add keyframes for pulse animation */}
      <style>{`
        @keyframes pulse {
          0%, 100% {
            opacity: 0.3;
            transform: scale(0.8);
          }
          50% {
            opacity: 1;
            transform: scale(1);
          }
        }
      `}</style>
    </div>
  );
}
