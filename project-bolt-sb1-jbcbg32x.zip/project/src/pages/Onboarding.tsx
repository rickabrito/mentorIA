import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { Target, Clock, Eye, Ear, BookOpen, Zap, Leaf, Rocket, ChevronRight, Sparkles } from 'lucide-react';
import type { OnboardingData } from '../utils/gemini';

export default function Onboarding() {
  const navigate = useNavigate();
  const [step, setStep] = useState(1);
  const [data, setData] = useState<OnboardingData>({
    goal: '',
    time: '',
    style: '',
    level: '',
  });

  const steps = [
    {
      title: 'Qual é o seu objetivo principal?',
      key: 'goal',
      options: [
        { value: 'concurso', label: 'Passar em concurso público', icon: <Target className="w-6 h-6" /> },
        { value: 'oab', label: 'Aprovação na OAB', icon: <Target className="w-6 h-6" /> },
        { value: 'carreira', label: 'Crescer na carreira jurídica', icon: <Rocket className="w-6 h-6" /> },
        { value: 'interesse', label: 'Aprender por interesse', icon: <BookOpen className="w-6 h-6" /> },
      ],
    },
    {
      title: 'Quanto tempo você tem para estudar por dia?',
      key: 'time',
      options: [
        { value: '10min', label: '10 minutos', icon: <Zap className="w-6 h-6" /> },
        { value: '30min', label: '30 minutos', icon: <Clock className="w-6 h-6" /> },
        { value: '1h', label: '1 hora', icon: <Clock className="w-6 h-6" /> },
        { value: '2h+', label: '2+ horas', icon: <Clock className="w-6 h-6" /> },
      ],
    },
    {
      title: 'Como você aprende melhor?',
      key: 'style',
      options: [
        { value: 'visual', label: 'Visual — prefiro diagramas e esquemas', icon: <Eye className="w-6 h-6" /> },
        { value: 'auditivo', label: 'Auditivo — prefiro ouvir explicações', icon: <Ear className="w-6 h-6" /> },
        { value: 'lendo', label: 'Lendo — prefiro texto e anotações', icon: <BookOpen className="w-6 h-6" /> },
        { value: 'praticando', label: 'Praticando — prefiro exercícios e exemplos', icon: <Zap className="w-6 h-6" /> },
      ],
    },
    {
      title: 'Como você avalia seu conhecimento hoje?',
      key: 'level',
      options: [
        { value: 'iniciante', label: 'Iniciante — estou começando do zero', icon: <Leaf className="w-6 h-6" /> },
        { value: 'intermediario', label: 'Intermediário — tenho base mas preciso avançar', icon: <BookOpen className="w-6 h-6" /> },
        { value: 'avancado', label: 'Avançado — quero aprofundar e revisar', icon: <Rocket className="w-6 h-6" /> },
      ],
    },
  ];

  const currentStep = steps[step - 1];

  const handleSelect = (value: string) => {
    setData({ ...data, [currentStep.key]: value });
  };

  const handleNext = () => {
    if (step < 4) {
      setStep(step + 1);
    } else {
      localStorage.setItem('onboarding_data', JSON.stringify(data));
      navigate('/analyzing');
    }
  };

  const canProceed = data[currentStep.key as keyof OnboardingData] !== '';

  return (
    <div className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Animated gradient background */}
      <div className="absolute inset-0 overflow-hidden">
        <div className="gradient-blob blob-purple w-96 h-96 -top-20 -left-20"></div>
        <div className="gradient-blob blob-cyan w-96 h-96 -bottom-20 -right-20"></div>
      </div>

      {/* Content */}
      <div className="relative z-10 w-full max-w-3xl px-6 fade-in">
        {/* Logo */}
        <div className="flex items-center justify-center gap-2 mb-8">
          <Sparkles className="w-8 h-8 text-purple-400" />
          <span className="text-2xl font-bold bg-gradient-to-r from-purple-400 to-cyan-400 bg-clip-text text-transparent">
            MentorIA
          </span>
        </div>

        {/* Progress Bar */}
        <div className="mb-8">
          <div className="flex justify-between items-center mb-2">
            <span className="text-sm text-gray-400">Passo {step} de 4</span>
            <span className="text-sm text-gray-400">{Math.round((step / 4) * 100)}%</span>
          </div>
          <div className="h-2 bg-white/10 rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-500 to-cyan-500 transition-all duration-500 ease-out"
              style={{ width: `${(step / 4) * 100}%` }}
            />
          </div>
        </div>

        {/* Step Content */}
        <div className="glass glow-border rounded-3xl p-8 md:p-12">
          <h2 className="text-3xl md:text-4xl font-bold text-center mb-8">
            {currentStep.title}
          </h2>

          {/* Options Grid */}
          <div className="grid md:grid-cols-2 gap-4 mb-8">
            {currentStep.options.map((option) => {
              const isSelected = data[currentStep.key as keyof OnboardingData] === option.value;
              return (
                <button
                  key={option.value}
                  onClick={() => handleSelect(option.value)}
                  className={`p-6 rounded-2xl border-2 transition-all text-left ${
                    isSelected
                      ? 'border-purple-500 bg-purple-500/20 glow-purple'
                      : 'border-white/10 bg-white/5 hover:border-purple-400/50'
                  }`}
                >
                  <div className="flex items-start gap-4">
                    <div className={`p-2 rounded-lg ${isSelected ? 'bg-purple-500/30' : 'bg-white/10'}`}>
                      <span className={isSelected ? 'text-purple-400' : 'text-gray-400'}>
                        {option.icon}
                      </span>
                    </div>
                    <span className="text-lg font-medium pt-1">{option.label}</span>
                  </div>
                </button>
              );
            })}
          </div>

          {/* Continue Button */}
          <button
            onClick={handleNext}
            disabled={!canProceed}
            className="w-full btn-gradient text-white font-semibold py-4 rounded-xl glow-purple disabled:opacity-50 disabled:cursor-not-allowed flex items-center justify-center gap-2"
          >
            {step < 4 ? (
              <>
                Continuar
                <ChevronRight className="w-5 h-5" />
              </>
            ) : (
              <>
                Criar meu plano
                <Sparkles className="w-5 h-5" />
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
}
